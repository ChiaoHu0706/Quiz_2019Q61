﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using vb = Microsoft.VisualBasic;

namespace Quiz_2019Q61
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            Now.Enabled = false;

            switch (button1.Text)
            {
                case "球賽計時器":
                    button1.Text = "暫停計時";
                    textBox1.Text = "24.0";
                    textBox2.BackColor = Color.Yellow;
                    CountDown24.Enabled = true;
                    break;
                case "計時開始":
                    button1.Text = "暫停計時";
                    textBox1.Text = "24.0";
                    textBox2.BackColor = Color.Yellow;
                    CountDown24.Enabled = true;

                    break;
                case "暫停計時":
                    button1.Text = "計時開始";
                    Now.Enabled = true;
                    textBox2.BackColor = Color.Yellow;
                    CountDown24.Enabled = false;
                    this.Text = "比賽暫停....." + minute + "分" + second + "秒(節)";
                    break;
                case "繼續下節":
                    button1.Text = "暫停計時";
                    textBox1.Text = "24.0";
                    textBox2.BackColor = Color.Yellow;
                    CountDown24.Enabled = true;
                    break;
                case "換邊發球":
                    button1.Text = "計時開始";
                    textBox1.Text = "24.0";
                    textBox2.BackColor = Color.Yellow;
                    CountDown24.Enabled = false;
                    Now.Enabled = true;
                    break;

            }

        }
        bool s = true;
        double total = 10.0;
        double second;
        int minute;
        private void timer1_Tick(object sender, EventArgs e)
        {
            total = total - 0.1;
            minute = (int)(total / 60);
            second = Math.Round((total % 60), 1);
            if (button1.Text == "暫停計時")
            {
                textBox1.Text = (double.Parse(textBox1.Text) - 0.1).ToString();

                textBox2.Text = textBox1.Text + "秒";
                this.Text = "NBA比賽進行中....此節僅剩" + minute + "分" + second + "秒(節)";
                if (double.Parse(textBox1.Text) <= 6.0 && double.Parse(textBox1.Text) > 0)
                {


                    if (s == true)
                    {
                        textBox2.BackColor = Color.Yellow;
                    }
                    else
                    {
                        textBox2.BackColor = Color.Red;
                    }
                    s = !s;
                }

                if (double.Parse(textBox1.Text) <= 0.0)
                {
                    CountDown24.Enabled = false;
                    textBox2.Text = "24秒違例";
                    textBox2.BackColor = Color.Red;
                    button1.Text = "換邊發球";
                }

            }
            if (total <= 0.0)
            {
                CountDown24.Enabled = false;
                Now.Enabled = true;
                string input = vb.Interaction.InputBox("繼續下節(Y/y)比賽結束(otherwise)", "本節結束，請按鍵選擇");

                if (input == "Y" || input == "y")
                {
                    total = 720.0;
                    CountDown24.Enabled = true;
                    Now.Enabled = true;
                    textBox1.Text = "24";
                    button1.Text = "繼續下節";
                }
                else
                {
                    this.Close();
                }


            }



        }

        private void Now_Tick(object sender, EventArgs e)
        {
            textBox2.Text = System.DateTime.Now.ToString();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {

            DialogResult dr = MessageBox.Show("To Exit", "提示訊息", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            switch (dr)
            {
                case System.Windows.Forms.DialogResult.Yes: e.Cancel = false; break;
                case System.Windows.Forms.DialogResult.No: e.Cancel = true; break;
            }

        }
    } 
}
